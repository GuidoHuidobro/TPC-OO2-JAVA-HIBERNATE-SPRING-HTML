package com.oo2.grupo10.services;

import com.oo2.grupo10.entities.PedidoAprov;
import com.oo2.grupo10.entities.Producto;
import java.util.List;

public interface IPedidoAprovService {

	List<PedidoAprov> getAll();

	void saveOrUpdate(PedidoAprov pedido);

	void delete(PedidoAprov pedido);

	void deleteByProducto(Producto producto);
}