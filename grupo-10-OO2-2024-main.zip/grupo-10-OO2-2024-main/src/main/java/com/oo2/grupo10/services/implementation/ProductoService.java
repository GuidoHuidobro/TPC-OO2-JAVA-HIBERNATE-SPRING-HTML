package com.oo2.grupo10.services.implementation;

import com.oo2.grupo10.entities.Producto;
import com.oo2.grupo10.repositories.IProductoRepository;
import com.oo2.grupo10.services.IProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service("productoService")
public class ProductoService implements IProductoService {

	@Autowired
	private IProductoRepository productoRepository;

	@Override
	public List<Producto> getAll() {
		List<Producto> productos = productoRepository.findAllActive();
		for (Producto producto : productos) {
			producto.setReabastecer(producto.getStockActual() <= producto.getStockMinimo());
		}

		return productos;
	}

	@Override
	public Optional<Producto> findById(int id) {
		return productoRepository.findByIdAndIsDeletedFalse(id);
	}

	@Override
	public void saveOrUpdate(Producto producto) {
		productoRepository.save(producto);
	}

	@Override
	public void delete(Producto producto) {
		producto.setDeleted(true);
		productoRepository.save(producto);
	}
}
