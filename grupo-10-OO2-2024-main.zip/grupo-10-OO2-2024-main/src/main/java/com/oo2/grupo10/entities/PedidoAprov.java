package com.oo2.grupo10.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "pedidoAprov")
public class PedidoAprov {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	@JoinColumn(name = "idProducto", nullable = false)
	private Producto producto;

	@Column(name = "cantidad")
	private int cantidad;

	@Column(name = "fechaPedido")
	private LocalDate fechaPedido;

	@Column(name = "proveedor")
	private String proveedor;

	@Column(name = "totalPedido")
	private double totalPedido;
	
	@Column(name = "estado")
	private String estado;

	public PedidoAprov(Producto producto, int cantidad, LocalDate fechaPedido, String proveedor, double totalPedido) {
		this.producto = producto;
		this.cantidad = cantidad;
		this.fechaPedido = fechaPedido;
		this.proveedor = proveedor;
		this.totalPedido = totalPedido;
	}
}