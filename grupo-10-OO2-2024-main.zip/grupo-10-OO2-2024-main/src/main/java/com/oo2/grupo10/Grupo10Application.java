package com.oo2.grupo10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Grupo10Application {

	public static void main(String[] args) {
		SpringApplication.run(Grupo10Application.class, args);
	}

}
