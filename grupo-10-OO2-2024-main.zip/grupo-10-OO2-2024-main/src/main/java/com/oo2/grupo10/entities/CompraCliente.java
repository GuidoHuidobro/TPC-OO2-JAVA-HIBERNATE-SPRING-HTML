package com.oo2.grupo10.entities;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "compracliente")
public class CompraCliente {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "compraCliente", cascade = CascadeType.ALL)
	private Set<Item> items = new HashSet<>();

	@Column(name = "fechaCompra")
	private LocalDate fechaCompra;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "usuario_id")
	private User usuario;

	public CompraCliente(LocalDate fechaCompra, User usuario) {
		this.fechaCompra = fechaCompra;
		this.usuario = usuario;
	}

	public CompraCliente(LocalDate fechaCompra, User usuario, Set<Item> items) {
		this.fechaCompra = fechaCompra;
		this.usuario = usuario;
		this.items = items;

	}

}
