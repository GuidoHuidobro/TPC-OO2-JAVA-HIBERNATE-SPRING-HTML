package com.oo2.grupo10.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import com.oo2.grupo10.entities.Producto;
import com.oo2.grupo10.helpers.ViewRouteHelper;
import com.oo2.grupo10.services.IProductoService;

@Controller
@RequestMapping("/producto")
public class ProductoController {

	@Autowired
	private IProductoService productoService;

	private ModelMapper modelMapper = new ModelMapper();

	public ProductoController(IProductoService productoService) {
		this.productoService = productoService;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("")
	public ModelAndView index() {
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.PRODUCTO_INDEX);
		mAV.addObject("productos", productoService.getAll());
		return mAV;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/new")
	public ModelAndView create() {
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.PRODUCTO_NEW);
		mAV.addObject("producto", new Producto());
		return mAV;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/create")
	public RedirectView create(@ModelAttribute("producto") Producto producto) {
		producto.setStockActual(0);
		producto.setReabastecer(true);
		producto.setDeleted(false);
		productoService.saveOrUpdate(producto);
		return new RedirectView(ViewRouteHelper.PRODUCTO_ROUTE);
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/edit/{id}")
	public ModelAndView edit(@PathVariable("id") int id) {
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.PRODUCTO_UPDATE);
		Producto producto = modelMapper.map(productoService.findById(id).get(), Producto.class);
		mAV.addObject("producto", producto);
		return mAV;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/update")
	public RedirectView edit(@ModelAttribute("producto") Producto producto) {
		Producto productoToUpdate = modelMapper.map(productoService.findById(producto.getId()).get(), Producto.class);
		if (productoToUpdate != null) {
			productoToUpdate.setNombre(producto.getNombre());
			productoToUpdate.setCodigo(producto.getCodigo());
			productoToUpdate.setDescripcion(producto.getDescripcion());
			productoToUpdate.setCosto(producto.getCosto());
			productoToUpdate.setPrecioVenta(producto.getPrecioVenta());
			productoToUpdate.setStockMinimo(producto.getStockMinimo());
			productoService.saveOrUpdate(productoToUpdate);
		}
		return new RedirectView(ViewRouteHelper.PRODUCTO_ROUTE);
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/delete/{id}")
	public ModelAndView delete(@PathVariable("id") int id) {
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.PRODUCTO_DELETE);
		Producto producto = modelMapper.map(productoService.findById(id).get(), Producto.class);
		mAV.addObject("producto", producto);
		return mAV;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/deleteConfirm")
	public RedirectView delete(@ModelAttribute("producto") Producto producto) {
		Producto productoToDelete = modelMapper.map(productoService.findById(producto.getId()).get(), Producto.class);
		if (productoToDelete != null) {
			productoService.delete(productoToDelete);
		}
		return new RedirectView(ViewRouteHelper.PRODUCTO_ROUTE);
	}

}