package com.oo2.grupo10.services.implementation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import com.oo2.grupo10.entities.CompraCliente;
import com.oo2.grupo10.entities.Item;
import com.oo2.grupo10.entities.Producto;
import com.oo2.grupo10.repositories.ICompraClienteRepository;
import com.oo2.grupo10.repositories.IUserRepository;
import com.oo2.grupo10.services.ICompraClienteService;
import com.oo2.grupo10.services.IItemService;
import com.oo2.grupo10.services.IProductoService;

@Service("compraClienteService")
public class CompraClienteService implements ICompraClienteService {

	@Autowired
	ICompraClienteRepository compraClienteRepository;

	@Autowired
	private IUserRepository userRepository;

	@Autowired
	private IProductoService productoService;

	@Autowired
	private IItemService itemService;

	private ModelMapper modelMapper = new ModelMapper();

	public List<CompraCliente> getAll() {
		return compraClienteRepository.findAll();
	}

	public Optional<CompraCliente> findById(int id) {
		return compraClienteRepository.findById(id);
	}

	public void save(CompraCliente compraCliente) {
		compraClienteRepository.save(compraCliente);
	}

	private List<String> error = new ArrayList<>();

	public List<String> getErrores() {
		return error;
	}

	public void clearErrores() {
		error.clear();
	}

	public List<CompraCliente> mostrarComprasFinalizadas() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		com.oo2.grupo10.entities.User user2 = userRepository.findByUsernameAndFetchUserRolesEagerly(user.getUsername());

		List<CompraCliente> compras = new ArrayList<CompraCliente>();
		for (CompraCliente compraCliente : getAll()) {
			if (compraCliente.getUsuario().getId() == user2.getId()) {
				compras.add(compraCliente);
			}
		}
		return compras;
	}

	public void agregarItem(int productoId, int cantidad) {
		Producto producto = modelMapper.map(productoService.findById(productoId).get(), Producto.class);
		boolean valido = false;
		Item itemNew = new Item(cantidad, producto);
		for (Item item : itemService.getItems()) {
			if (item.getProducto().getId() == itemNew.getProducto().getId()) {
				item.setCantidad(item.getCantidad() + itemNew.getCantidad());
				valido = true;
			}
		}
		if (!valido) {
			itemService.addItem(itemNew);

		}
	}

	public void deleteItem(int productoId) {
		Producto producto = modelMapper.map(productoService.findById(productoId).get(), Producto.class);

		Item elimiarItem = null;

		// busca el item a eliminar

		for (Item item2 : itemService.getItems()) {
			if (item2.getProducto().getId() == producto.getId()) {
				elimiarItem = item2;

			}
		}
		// Lo tuve que hacer de esta manera porque no me funcionaba bien el remove de
		// set, al parecer tira error cuando vuelvo a correr la lista
		if (elimiarItem != null) {
			Set<Item> listaNueva = new HashSet<>();
			for (Item item2 : itemService.getItems()) {
				// cargo la nueva lista
				if (item2.getProducto().getId() != elimiarItem.getProducto().getId()) {
					listaNueva.add(item2);
				}
			}
			// limpio la lista actual
			itemService.getItems().clear();
			// le agrego los items q no fueron eliminados
			for (Item item : listaNueva) {
				itemService.addItem(item);
				;
			}
		}

	}

	public void finalizarCompra() {
		clearErrores();

		if (!itemService.getItems().isEmpty()) {

			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			com.oo2.grupo10.entities.User user2 = userRepository
					.findByUsernameAndFetchUserRolesEagerly(user.getUsername());
			Set<Item> items = new HashSet<>();
			for (Item item2 : itemService.getItems()) {
				items.add(item2);
			}

			for (Item item : items) {
				Producto producto = modelMapper.map(productoService.findById(item.getProducto().getId()).get(),
						Producto.class);
				if (item.getCantidad() <= producto.getStockActual()) {
					producto.setStockActual(producto.getStockActual() - item.getCantidad());
					productoService.saveOrUpdate(producto);

				} else {

					getErrores().add("El Articulo " + item.getProducto().getNombre()
							+ " no tiene el stock solicitado y fue eliminado");

					itemService.getItems().remove(item);
				}
			}
			if (!itemService.getItems().isEmpty()) {
				CompraCliente compraCliente = new CompraCliente(LocalDate.now(), user2, itemService.getItems());
				for (Item itemid : itemService.getItems()) {
					itemid.setCompraCliente(compraCliente);
				}

				save(compraCliente);
				itemService.setItems();
			} else {
				getErrores().add("No hay compras agregadas");
			}

		} else {
			getErrores().add("No hay compras");
		}
	}
}
