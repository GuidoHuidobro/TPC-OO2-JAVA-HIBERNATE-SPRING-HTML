package com.oo2.grupo10.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import com.oo2.grupo10.entities.PedidoAprov;
import com.oo2.grupo10.entities.Producto;
import com.oo2.grupo10.services.IPedidoAprovService;
import com.oo2.grupo10.services.IProductoService;
import com.oo2.grupo10.helpers.ViewRouteHelper;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/pedido_aprov")
public class PedidoAprovController {

	@Autowired
	private IPedidoAprovService pedidoAprovService;

	@Autowired
	private IProductoService productoService;

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("")
	public ModelAndView index() {
		ModelAndView mav = new ModelAndView(ViewRouteHelper.PEDIDOAPROV_INDEX);
		List<PedidoAprov> pedidos = pedidoAprovService.getAll();
		mav.addObject("pedidos", pedidos);
		return mav;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/new")
	public ModelAndView createPedido(@RequestParam(name = "idProducto", required = false) Integer idProducto) {
		ModelAndView mav = new ModelAndView(ViewRouteHelper.PEDIDOAPROV_NEW);

		// Si se proporciona un idProducto, se preselecciona ese producto en el
		// formulario
		if (idProducto != null) {
			Optional<Producto> optionalProducto = productoService.findById(idProducto);
			if (optionalProducto.isPresent()) {
				PedidoAprov pedido = new PedidoAprov();
				pedido.setProducto(optionalProducto.get());
				mav.addObject("pedido", pedido);
			} else {
				mav.addObject("error", "El producto con ID " + idProducto + " no existe");
				mav.setViewName("error");
			}
		} else {
			// Si no se proporciona un idProducto, se crea un pedido nuevo sin producto
			// seleccionado
			mav.addObject("pedido", new PedidoAprov());
		}

		mav.addObject("productos", productoService.getAll());
		return mav;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/create")
	public ModelAndView createPedido(@ModelAttribute("pedido") PedidoAprov pedido) {
		pedido.setFechaPedido(LocalDate.now());
		double totalPedido = pedido.getCantidad() * pedido.getProducto().getPrecioVenta();
		pedido.setTotalPedido(totalPedido);
		pedido.setEstado("Pendiente");

		pedidoAprovService.saveOrUpdate(pedido);

		ModelAndView mav = new ModelAndView(ViewRouteHelper.PEDIDO_CREATION_SUCCESS);
		mav.addObject("mensaje", "¡Pedido creado exitosamente!");
		return mav;
	}

}