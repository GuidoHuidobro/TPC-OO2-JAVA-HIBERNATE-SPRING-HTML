package com.oo2.grupo10.helpers;

public class ViewRouteHelper {

	// ----VISTAS----//

	// HOME
	public final static String INDEX = "home/index";

	// USER
	public final static String USER_LOGIN = "user/login";
	public final static String USER_LOGOUT = "user/logout";

	// COMPRACLIENTE
	public final static String COMPRACLIENTE_INDEX = "compracliente/index";
	public final static String COMPRACLIENTE_FINISHED = "compracliente/finished";

	// PRODUCTO
	public final static String PRODUCTO_INDEX = "producto/index";
	public final static String PRODUCTO_NEW = "producto/new";
	public final static String PRODUCTO_UPDATE = "producto/update";
	public final static String PRODUCTO_DELETE = "producto/delete";

	// LOTE
	public final static String LOTE_INDEX = "lote/index";
	public final static String LOTE_NEW = "lote/new";

	// PEDIDOAPROV
	public final static String PEDIDOAPROV_INDEX = "pedido_aprov/index";
	public final static String PEDIDOAPROV_NEW = "pedido_aprov/new";
	public final static String PEDIDO_CREATION_SUCCESS = "pedido_aprov/pedido_creation_success";

	// STOCK
	public final static String STOCK_INDEX = "stock/index";

	// VENTA
	public final static String VENTAS_INDEX = "ventas/index";

	// REDIRECCIONES
	public final static String ROUTE = "/index";
	public final static String PRODUCTO_ROUTE = "/producto";
	public final static String PEDIDOAPRV_ROUTE = "/pedido_aprov";
	public final static String COMPRACLIENTE_ROUTE = "/compracliente";
	public final static String LOTE_ROUTE = "/lote";

}
