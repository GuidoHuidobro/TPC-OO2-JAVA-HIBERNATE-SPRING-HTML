package com.oo2.grupo10.controllers;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import com.oo2.grupo10.helpers.ViewRouteHelper;
import com.oo2.grupo10.services.ICompraClienteService;

@Controller
@RequestMapping("/")
public class HomeController {
	@Autowired
	private ICompraClienteService compraClienteService;

	@GetMapping("/index")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView(ViewRouteHelper.INDEX);
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		compraClienteService.clearErrores();

		modelAndView.addObject("username", user.getUsername());
		modelAndView.addObject("userRoles",
				user.getAuthorities().stream().map(authority -> authority.getAuthority()).collect(Collectors.toList()));
		return modelAndView;
	}

	@GetMapping("/")
	public RedirectView redirectToHomeIndex() {
		return new RedirectView(ViewRouteHelper.ROUTE);
	}

}
