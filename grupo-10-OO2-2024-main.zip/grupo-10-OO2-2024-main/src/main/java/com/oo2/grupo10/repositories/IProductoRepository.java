package com.oo2.grupo10.repositories;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.oo2.grupo10.entities.Producto;

@Repository("productoRepository")
public interface IProductoRepository extends JpaRepository<Producto, Serializable> {

	@Query("SELECT p FROM Producto p WHERE p.isDeleted = false")
	List<Producto> findAllActive();

	@Query("SELECT p FROM Producto p WHERE p.id = :id AND p.isDeleted = false")
	Optional<Producto> findByIdAndIsDeletedFalse(@Param("id") int id);
}