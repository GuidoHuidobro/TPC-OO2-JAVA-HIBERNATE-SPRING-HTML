package com.oo2.grupo10.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import com.oo2.grupo10.helpers.ViewRouteHelper;
import com.oo2.grupo10.services.ICompraClienteService;
import com.oo2.grupo10.services.IItemService;
import com.oo2.grupo10.services.IProductoService;

@Controller
@RequestMapping({ "/compracliente" })
public class CompraClienteController {

	@Autowired
	private IProductoService productoService;

	@Autowired
	private ICompraClienteService compraClienteService;

	@Autowired
	private IItemService itemService;

	@PreAuthorize("hasRole('ROLE_CLIENTE')")
	@GetMapping("")
	public ModelAndView index() {
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.COMPRACLIENTE_INDEX);
		mAV.addObject("items", itemService.getItems());
		mAV.addObject("productos", productoService.getAll());
		mAV.addObject("error", compraClienteService.getErrores());
		return mAV;
	}

	
	@PreAuthorize("hasRole('ROLE_CLIENTE')")
	@GetMapping("/finished")
	public ModelAndView finished() {
		compraClienteService.clearErrores();
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.COMPRACLIENTE_FINISHED);

		mAV.addObject("finisheds", compraClienteService.mostrarComprasFinalizadas());
		return mAV;

	}

	@PreAuthorize("hasRole('ROLE_CLIENTE')")
	@PostMapping("/addItem")
	public RedirectView addItem(@RequestParam("productoId") int productoId, @RequestParam("cantidad") int cantidad) {
		compraClienteService.agregarItem(productoId, cantidad);
		return new RedirectView(ViewRouteHelper.COMPRACLIENTE_ROUTE);
	}
	
	@PreAuthorize("hasRole('ROLE_CLIENTE')")
	@PostMapping("/deleteItem")
	public RedirectView deleteItem(@RequestParam("productoId") int productoId) {
		compraClienteService.deleteItem(productoId);
		return new RedirectView(ViewRouteHelper.COMPRACLIENTE_ROUTE);
	}

	@PreAuthorize("hasRole('ROLE_CLIENTE')")
	@PostMapping("/finCompra")
	public RedirectView finCompra() {
		compraClienteService.finalizarCompra();
		return new RedirectView(ViewRouteHelper.COMPRACLIENTE_ROUTE);
	}

}