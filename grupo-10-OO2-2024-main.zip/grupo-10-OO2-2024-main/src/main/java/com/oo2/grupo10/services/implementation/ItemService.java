package com.oo2.grupo10.services.implementation;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.oo2.grupo10.entities.Item;
import com.oo2.grupo10.repositories.IItemRepository;
import com.oo2.grupo10.services.IItemService;

@Service("itemService")
public class ItemService implements IItemService {

	@Autowired
	IItemRepository itemRepository;

	public void save(Item item) {
		itemRepository.save(item);
	}

	public List<Item> getAll() {

		return itemRepository.findAll();
	}

	private Set<Item> items = new HashSet<>();

	public Set<Item> getItems() {
		return items;
	}

	public void setItems() {
		items = new HashSet<>();
	}

	public void addItem(Item item) {
		items.add(item);
	}

}
