package com.oo2.grupo10.repositories;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.oo2.grupo10.entities.CompraCliente;

@Repository("compraClienteRepository")
public interface ICompraClienteRepository extends JpaRepository<CompraCliente, Serializable> {

}
