package com.oo2.grupo10.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.oo2.grupo10.helpers.ViewRouteHelper;
import com.oo2.grupo10.services.IProductoService;

@Controller
@RequestMapping("/stock")
public class StockController {

	@Autowired
	private IProductoService productoService;

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("")
	public ModelAndView index() {
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.STOCK_INDEX);
		mAV.addObject("productos", productoService.getAll());
		return mAV;
	}
}
