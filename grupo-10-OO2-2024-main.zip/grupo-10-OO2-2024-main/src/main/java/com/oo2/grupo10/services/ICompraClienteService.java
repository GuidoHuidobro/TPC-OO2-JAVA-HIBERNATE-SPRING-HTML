package com.oo2.grupo10.services;

import java.util.List;
import java.util.Optional;
import com.oo2.grupo10.entities.CompraCliente;

public interface ICompraClienteService {

	public List<CompraCliente> getAll();

	public Optional<CompraCliente> findById(int id);

	public void save(CompraCliente compraCliente);

	public List<String> getErrores();

	public void clearErrores();

	public List<CompraCliente> mostrarComprasFinalizadas();

	public void agregarItem(int productoId, int cantidad);

	public void deleteItem(int productoId);

	public void finalizarCompra();
}
