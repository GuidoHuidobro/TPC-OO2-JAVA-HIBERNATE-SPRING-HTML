package com.oo2.grupo10.services;

import java.util.List;
import com.oo2.grupo10.entities.Lote;
import com.oo2.grupo10.entities.PedidoAprov;

public interface ILoteService {

	public List<Lote> getAll();

	public void save(Lote lote);

	public List<PedidoAprov> filtrarPedidoSinLote(List<PedidoAprov> todosLosPedidos, List<Lote> lotes);
}
