package com.oo2.grupo10.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Item {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idItem;
	
	@Column(name = "cantidad")
	private int cantidad;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "compraCliente_id")
	private CompraCliente compraCliente;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "producto_id")
	private Producto producto;
	
	
	public Item(int cantidad, Producto producto) {
		this.cantidad = cantidad;
		this.producto = producto;
	}

	public Item(int cantidad, Producto producto, CompraCliente compraCliente) {
		this.cantidad = cantidad;
		this.compraCliente = compraCliente;
		this.producto = producto;
	}

	@Override
	public String toString() {
		return "Item{id=" + idItem + ", cantidad='" + cantidad + "', producto=" + producto + "}";

	}
}
