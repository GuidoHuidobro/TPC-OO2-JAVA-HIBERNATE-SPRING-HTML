package com.oo2.grupo10.repositories;

import com.oo2.grupo10.entities.PedidoAprov;
import com.oo2.grupo10.entities.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository("pedidoAprovRepository")
public interface IPedidoAprovRepository extends JpaRepository<PedidoAprov, Integer> {

	List<PedidoAprov> findByProducto(Producto producto);

	void deleteByProducto(Producto producto);
}