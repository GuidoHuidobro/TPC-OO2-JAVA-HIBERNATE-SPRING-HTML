package com.oo2.grupo10.services;

import java.util.List;
import java.util.Set;
import com.oo2.grupo10.entities.Item;

public interface IItemService {

	public void save(Item item);

	public List<Item> getAll();

	public Set<Item> getItems();

	public void addItem(Item item);

	public void setItems();

}
