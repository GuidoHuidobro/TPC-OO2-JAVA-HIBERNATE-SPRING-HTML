package com.oo2.grupo10.services;

import java.util.List;
import java.util.Optional;
import com.oo2.grupo10.entities.Producto;

public interface IProductoService {

	public List<Producto> getAll();

	public Optional<Producto> findById(int id);

	public void saveOrUpdate(Producto producto);

	public void delete(Producto producto);
}