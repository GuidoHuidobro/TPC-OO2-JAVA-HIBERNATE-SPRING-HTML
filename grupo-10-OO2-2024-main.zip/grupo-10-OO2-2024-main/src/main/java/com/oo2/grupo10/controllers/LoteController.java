package com.oo2.grupo10.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import com.oo2.grupo10.entities.Lote;
import com.oo2.grupo10.entities.PedidoAprov;
import com.oo2.grupo10.helpers.ViewRouteHelper;
import com.oo2.grupo10.services.ILoteService;
import com.oo2.grupo10.services.IPedidoAprovService;

@Controller
@RequestMapping("/lote")
public class LoteController {

	@Autowired
	private ILoteService loteService;
	@Autowired
	private IPedidoAprovService pedidoAprovService;

	public LoteController(ILoteService loteService) {
		this.loteService = loteService;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("")
	public ModelAndView index() {
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.LOTE_INDEX);
		mAV.addObject("lotes", loteService.getAll());
		return mAV;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@GetMapping("/new")
	public ModelAndView create() {
		ModelAndView mAV = new ModelAndView(ViewRouteHelper.LOTE_NEW);
		List<PedidoAprov> todosLosPedidos = pedidoAprovService.getAll();
		List<Lote> lotes = loteService.getAll();

		mAV.addObject("pedidosAprov", loteService.filtrarPedidoSinLote(todosLosPedidos, lotes));

		mAV.addObject("lote", new Lote());
		return mAV;
	}

	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/create")
	public RedirectView create(@ModelAttribute("lote") Lote lote) {

		loteService.save(lote);
		return new RedirectView(ViewRouteHelper.LOTE_ROUTE);
	}

}
