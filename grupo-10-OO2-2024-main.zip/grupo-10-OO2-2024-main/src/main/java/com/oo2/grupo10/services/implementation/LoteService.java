package com.oo2.grupo10.services.implementation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.oo2.grupo10.repositories.ILoteRepository;
import com.oo2.grupo10.entities.Lote;
import com.oo2.grupo10.entities.PedidoAprov;
import com.oo2.grupo10.services.ILoteService;
import com.oo2.grupo10.services.IProductoService;

@Service("loteService")
public class LoteService implements ILoteService {
	@Autowired
	ILoteRepository loteRepository;
	@Autowired
	private IProductoService productoService;

	@Override
	public List<Lote> getAll() {
		return loteRepository.findAll();

	}

	public void save(Lote lote) {
		lote.setProducto(lote.getPedidoAprov().getProducto());
		lote.setCantidad(lote.getPedidoAprov().getCantidad());
		lote.setProveedor(lote.getPedidoAprov().getProveedor());
		lote.setFechaRecepcion(LocalDate.now());
		lote.setTotalLote(lote.getPedidoAprov().getTotalPedido());

		lote.getPedidoAprov().getProducto().setStockActual(
				lote.getPedidoAprov().getProducto().getStockActual() + lote.getPedidoAprov().getCantidad());

		lote.getPedidoAprov().setEstado("Entregado");
		productoService.saveOrUpdate(lote.getPedidoAprov().getProducto());

		loteRepository.save(lote);

	}

	public List<PedidoAprov> filtrarPedidoSinLote(List<PedidoAprov> todosLosPedidos, List<Lote> lotes) {

		List<PedidoAprov> pedidosSinLotes = new ArrayList<PedidoAprov>();
		Set<Integer> pedidosConLotesIds = new HashSet<>();

		for (Lote l : lotes) {
			pedidosConLotesIds.add(l.getPedidoAprov().getId());
		}
		for (PedidoAprov p : todosLosPedidos) {
			if (!pedidosConLotesIds.contains(p.getId())) {
				pedidosSinLotes.add(p);
			}
		}

		return pedidosSinLotes;
	}
}
