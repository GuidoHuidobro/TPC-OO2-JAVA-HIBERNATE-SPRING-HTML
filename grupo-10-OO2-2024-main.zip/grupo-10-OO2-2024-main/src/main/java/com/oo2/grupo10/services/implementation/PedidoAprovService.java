package com.oo2.grupo10.services.implementation;

import com.oo2.grupo10.entities.PedidoAprov;
import com.oo2.grupo10.entities.Producto;
import com.oo2.grupo10.repositories.IPedidoAprovRepository;
import com.oo2.grupo10.services.IPedidoAprovService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("pedidoAprovService")
public class PedidoAprovService implements IPedidoAprovService {

	@Autowired
	private IPedidoAprovRepository pedidoAprovRepository;

	@Override
	public List<PedidoAprov> getAll() {
		return pedidoAprovRepository.findAll();
	}

	@Override
	public void saveOrUpdate(PedidoAprov pedido) {
		pedidoAprovRepository.save(pedido);
	}

	@Override
	public void delete(PedidoAprov pedido) {
		pedidoAprovRepository.delete(pedido);
	}

	@Override
	public void deleteByProducto(Producto producto) {
		pedidoAprovRepository.deleteByProducto(producto);
	}
}