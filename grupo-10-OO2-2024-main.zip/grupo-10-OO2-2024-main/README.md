# grupo-10-OO2-2024
Integrantes: 
- Velardez, Lucila
- Huidobro, Guido
- Brañas Gramajo, Martina 
- Vargas, Valentina 

Como levantar el proyecto

Link del video:
https://drive.google.com/file/d/1zLNc4FzGeUc60Hcr4QjDaYeadrkfkzJp/view?usp=sharing

Link del repositorio: https://github.com/GuidoHuidobro/grupo-10-OO2-2024

Para poder levantar el proyecto, es necesario contar con las siguientes
herramientas: JAVA (versión 17), MySQL, Spring Tool Suite, Maven y Lombok. Se
requiere clonar el proyecto con la última actualización en la branch `main` se lo
importa en el IDE y antes de ejecutar el proyecto, se debe crear una base de datos
llamada `grupo10_stock` en MySQL y configurar correctamente las variables de
entorno de la siguiente manera, según sus datos de base de datos:

Variable: DB_URL
Value:jdbc:mysql://localhost/grupo10_stock?serverTimezone=UTC
Variable: USERNAME Value: root (lo que corresponda)
Variable: PASSWORD Value: 123 (lo que corresponda)

Una vez agregadas correctamente estas variables, se puede correr el proyecto para
que se creen las tablas en la base de datos. Para poder acceder al Login, se deben
crear usuarios con su Rol, ya sea de Admin o de Cliente. Esta es la query para su
creación en la base de datos:

//CREACIÓN DE USUARIOS (contraseña siempre es “123”)
//ADMINISTRADOR

INSERT INTO grupo10_stock.user

(enabled, password, username)
VALUES
(b'1', '$2a$10$zrAbv8k5j8ZN63AKpm8lY.OEzU.OeQghagnBd/eqt4z6ydQchsL16', 'Admin');

//CLIENTE

INSERT INTO grupo10_stock.user

(enabled, password, username)
VALUES
(b'1', '$2a$10$zrAbv8k5j8ZN63AKpm8lY.OEzU.OeQghagnBd/eqt4z6ydQchsL16', 'Cliente');

//CREACIÓN DE LOS ROLES DE USUARIO
//ADMINISTRADOR

INSERT INTO grupo10_stock.user_role

(role, user_id)
VALUES
('ROLE_ADMIN', 1);

//CLIENTE

INSERT INTO grupo10_stock.user_role

(role, user_id)
VALUES
('ROLE_CLIENTE', 2);

Y finalmente, si quieren integrar productos sin hacer el procedimiento del proyecto,
aquí dejamos la query para insertar productos rápidamente:

//AGREGAR PRODUCTOS EN BD

INSERT INTO grupo10_stock.producto

(codigo,costo,descripcion,is_deleted,nombre,precio_venta,
reabastecer,stock_actual,stock_minimo)
VALUES

('1', 1062,'Agua Mineral Sin Gas 2L', 0,'Villavicencio',2062, 0 ,15,1),

('2', 8800,'Branca Clásico 750mL',0,'Fernet',9900,0,25,1),

('3', 1865,'Con Pulpa Citric 1L',0,'Jugo De Naranja',1994,0,7,1),

('4', 1159,'Chocolate x 60gr',0,'Oblea mini Rhodesias',1260,0,22,1),

('5', 449,'Dulce De Membrillo Mermelada',0,'Galletitas Pepas',567,0,34,1),

('6', 1152,'Matarazzo 500g',0,'Fideos Tallarín',1283,0,59,1),

('7', 1254,'Sin TACC en doypack 500 ml',0,'Mayonesa Natura',1537,0,78,1),

('8', 5400,'Crema De Avellanas 350g',0,'Nutella',6601,0,11,1),

('9', 1800,'Clásico Tregar X 400 g',0,'Dulce De Leche',2010,0,28,1),

('10', 7892,'Caja De 12 Bombones',0,'Chocolate Ferrero Rocher',8593,0,5,1),

('11', 2146,'Botella 710mL',0,'Cerveza Corona',2876,0,45,1);
